# Flickz By Oscar website

## Publish with GitHub Pages
1. Create a **public** repository named `YOURUSERNAME.github.io` (replace with your GitHub username).
2. Upload `index.html` to the repository root.
3. Open Settings -> Pages.
4. Under Build and deployment, select Deploy from a branch, branch `main`, folder `/ (root)`, then Save.
5. Wait a few minutes, then visit `https://YOURUSERNAME.github.io`.

## Customize
- Instagram handle is set to `flickzbyoscar` in `index.html`.
- SMS number is set in the `PHONE` constant and the Text Me link.
- The booking form opens the visitor's messaging app with a prefilled request. It does not send automatically.
- Replace the portfolio placeholder panels with your own photos when ready.
- The presets and prints are launch-soon sections; secure checkout requires a separate payment/store service.

Privacy: only publish a phone number intended for public business contact. Consider using a dedicated business number and get a parent/guardian's approval before publishing contact or payment details.


## Preset checkout and automatic delivery
The store now has two preset product cards with Buy Presets buttons. They are not live until you:
1. With a parent/guardian handling the seller/payment account, create the digital preset products in Payhip.
2. Upload the actual preset files (usually a ZIP containing the Lightroom preset files and simple install instructions).
3. Copy each Payhip product URL.
4. In index.html, find PRESET_CHECKOUT_URLS and paste the matching URLs between the quotation marks for `signature` and `sports`.
5. Upload the updated index.html to GitHub Pages.

Payhip's free plan currently has no monthly fee and a 5% Payhip transaction fee, plus the payment processor's fee. Payhip says successful digital purchases are delivered on a download page and the buyer receives an email receipt with the download link. Check current terms and payment-provider requirements with your parent/guardian before activating sales.
